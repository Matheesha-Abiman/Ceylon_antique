package lk.ijse.backend.entity;

public enum Role {
    ADMIN,USER
}