package lk.ijse.backend.dto;

import lombok.Data;

@Data
public class AuthDTO {
    private String username;
    private String password;
}