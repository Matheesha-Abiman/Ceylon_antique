package lk.ijse.backend.controller;

public class SettingsController {
}
